import React from 'react'
import Footer from './Footer'
function PageNotFound() {
    return (
      <>
            <div>PageNotFound</div>
            <Footer></Footer>
      </>
    );
}

export default PageNotFound
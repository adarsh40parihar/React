import React from 'react'
import Footer from './Footer'
import Header from './Header'
function Home() {
    return (
      <>
            <div>Home</div>
            <Header></Header>
            <main>I am Main</main>
            <Footer></Footer>
      </>
    );
}

export default Home